To start VPN session, please move on /home folder both on server and client!! (r5 and s containers)
